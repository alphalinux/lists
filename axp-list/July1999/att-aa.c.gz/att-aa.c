#include <stdlib.h>
#include <sys/types.h>

#include <fpu_control.h>
#if defined (__alpha__)
#include <asm/fpu.h>
#define	LONG	long
#else
#define	LONG	long long
#endif

main()
{
	int digits8 = 32;

	struct	{
		double A,B,C;
	} result;

	struct	{
		double x, y;
	} pt1, pt2;

                union {
                        double  q;
                        LONG    l;
                        int     i[2];
                } t1, t2, t3, t1x,t1y, t2x,t2y;

#if defined(__alpha__)
__setfpucw (0);
#endif

	pt1.x = -1000000, pt1.y = 200;
	pt2.x =   300000, pt2.y = -40;

#if 0
                result.A = (pt2.y - pt1.y) / (pt2.x - pt1,x);
                result.C = pt1.y - result.A * pt1.x;
#else
                t1.q = (pt2.y - pt1.y);
                t2.q = (pt2.x - pt1.x);
                t3.q = result.A = t1.q / t2.q;
                t1x.q = pt1.x, t1y.q = pt1.y;
                t2x.q = pt2.x, t2y.q = pt2.y;

printf("l_c \tpt1->x=%.*g(%Lx) \n\tpt1->y=%.*g(%Lx),,\n\tpt2->x=%.*g(%Lx),\n\tpt2->y=%.*g(%Lx)\n",
        digits8, t1x.q,t1x.l,
        digits8, t1y.q,t1y.l,
        digits8, t2x.q,t2x.l,
        digits8, t2y.q,t2y.l);
printf("lc \tt1.q=%.*g(%Lx), \n\tt2.q=%.*g(%Lx), \n\tresult = %.*g(%Lx)\n",
        digits8, t1.q,t1.l,
        digits8, t2.q,t2.l,
        digits8, t3.q,t3.l);

                t1.q = result.A * pt1.x;
                t2.q = pt1.y - t1.q;
                t3.q = result.C = pt1.y - result.A * pt1.x;
printf("lc- \tt1 =%.*g(%Lx), \n\tt2 =%.*g(%Lx), \n\tr.C=%.*g(%Lx)\n",
        digits8, t1.q, t1.l,
        digits8, t2.q, t2.l,
        digits8, t3.q, t3.l);
#endif
}
/*
(L3) 15.3864610140472(0x402ec5de37d1061b) = -0.000184615384615385(0xbf2832aa141a169f) * -9.99715942258202(0xc023fe8bae09c6ac) + 15.3846153846154(0x402ec4ec4ec4ec50)
(L3) 15.3864610140473(402ec5de37d1061f) = -0.000184615384615385(bf2832aa141a169f) * -9.99715942258202(c023fe8bae09c6ac) + 15.3846153846154(402ec4ec4ec4ec54)

line_construct_pp pt1->x=-1000000(c12e848000000000) pt1->y=200(4069000000000000),,pt2->x=300000(41124f8000000000),pt2->y=-40(c044000000000000)
line_construct_pp t1.q=-240(c06e000000000000), t2.q=1300000(4133d62000000000), result = -0.000184615384615385(bf2832aa141a169f)
line_construct_pp- result->C=15.3846153846154(402ec4ec4ec4ec54)
line_construct_pp- line is neither vertical nor horizontal (diffs x=1300000, y=-240
(L3) 15.3864610140473(402ec5de37d1061f) = -0.000184615384615385(bf2832aa141a169f) * -9.99715942258202(c023fe8bae09c6ac) + 15.3846153846154(402ec4ec4ec4ec54)
(L3) line_interpt- lines intersect at (-9.99715942258202,15.3864610140473)
line_interpt- lines are A=-0.000184615384615385, B=-1, C=15.3846153846154, A=5416.66666666667, B=-1, C=54166.6666666667
line_interpt- lines intersect at (-9.99715942258202,15.3864610140473)

*/

#if defined(__alpha__)
extern void		__ieee_set_fp_control (unsigned long);
extern unsigned long	__ieee_get_fp_control (void);

static inline unsigned long
rdfpcr (void)
{
  unsigned long fpcr;
  asm ("excb; mf_fpcr %0" : "=f"(fpcr));
  return fpcr;
}


static inline void
wrfpcr (unsigned long fpcr)
{
  asm volatile ("mt_fpcr %0; excb" : : "f"(fpcr));
}


void
__setfpucw (fpu_control_t fpu_control)
{
  unsigned long fpcr = 0, fpcw = 0;

  if (!fpu_control)
    fpu_control = _FPU_DEFAULT;

  /* first, set dynamic rounding mode: */

  fpcr = rdfpcr();

printf("Currently FPCR = %p\n", fpcr );

  fpcr &= ~FPCR_DYN_MASK;
  switch (fpu_control & 0xc00)
    {
    case _FPU_RC_NEAREST:	fpcr |= FPCR_DYN_NORMAL; break;
    case _FPU_RC_DOWN:		fpcr |= FPCR_DYN_MINUS; break;
    case _FPU_RC_UP:		fpcr |= FPCR_DYN_PLUS; break;
    case _FPU_RC_ZERO:		fpcr |= FPCR_DYN_CHOPPED; break;
    }
  wrfpcr(fpcr);
}
#endif
